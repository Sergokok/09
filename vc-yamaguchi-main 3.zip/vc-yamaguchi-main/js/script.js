const blackHole = document.querySelector(".black-hole");
const bounceDoll = document.querySelector(".bounce");

// if (window.innerWidth > 320) {
//   // alert("hjhhh"); //работает
// }

// function dollAppear() {
//   // alert("Привет"); //работает
//   blackHole.style.height = "50px";
//   blackHole.style.width = "120px";
// }
// setTimeout(dollAppear, 1000);
